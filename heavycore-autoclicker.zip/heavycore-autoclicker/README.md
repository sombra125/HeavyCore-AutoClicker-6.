# HeavyCore AutoClicker

Mod **client-side** para Minecraft Java **1.21.1 + Fabric**.

## Qué hace
- Usa los datos del objeto de vista previa del Vault (no reconocimiento de pantalla).
- Solo actúa cuando miras directamente un **cofre ominoso**.
- Si el objeto que el Vault muestra girando es `minecraft:heavy_core`, envía **un clic derecho** al bloque.
- No repite el clic mientras siga apareciendo el mismo Núcleo Pesado. Se rearma cuando el objeto mostrado cambia y vuelve a aparecer.
- Tecla **H** para activar/desactivar.

No requiere instalarse en el servidor. El servidor puede tener reglas contra automatización; úsalo solo donde esté permitido.

## Compilar
Necesitas Java 21 y Gradle 8.10.2 o compatible con Fabric Loom 1.8.

```bash
gradle build
```

El JAR queda en `build/libs/heavycore-autoclicker-1.0.0.jar`.

## Instalar
1. Instala Fabric Loader para Minecraft 1.21.1.
2. Instala Fabric API para 1.21.1.
3. Copia el JAR compilado a la carpeta `.minecraft/mods`.
4. Entra al juego, apunta al cofre ominoso y deja activado el mod (H).

## Nota técnica
El mod consulta `VaultBlockEntity.getSharedData().getDisplayItem()` en el cliente. Esto es más fiable que intentar reconocer el modelo giratorio mediante capturas de pantalla.
