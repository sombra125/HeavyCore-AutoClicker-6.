package com.omar.heavycore;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class HeavyCoreAutoClicker implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = true;
    private static boolean clickedForCurrentAppearance = false;
    private static BlockPos lastVaultPos = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.heavycore_autoclicker.toggle",
                GLFW.GLFW_KEY_H,
                KeyBinding.MISC_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(HeavyCoreAutoClicker::onClientTick);
    }

    private static void onClientTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            clickedForCurrentAppearance = false;
            if (client.player != null) {
                client.player.sendMessage(Text.literal("[HeavyCore AutoClicker] " + (enabled ? "Activado" : "Desactivado")), true);
            }
        }

        if (client.player == null || client.world == null || client.interactionManager == null) {
            resetTracking();
            return;
        }

        if (!enabled) {
            return;
        }

        // Keep the latch while looking away, so the same appearance cannot trigger twice.
        if (lastVaultPos != null) {
            BlockEntity trackedEntity = client.world.getBlockEntity(lastVaultPos);
            if (trackedEntity instanceof VaultBlockEntity trackedVault) {
                ItemStack trackedDisplay = trackedVault.getSharedData().getDisplayItem();
                if (trackedDisplay.isEmpty() || !trackedDisplay.isOf(Items.HEAVY_CORE)) {
                    clickedForCurrentAppearance = false;
                }
            }
        }

        if (client.crosshairTarget == null || client.crosshairTarget.getType() != HitResult.Type.BLOCK) {
            return;
        }

        BlockHitResult hit = (BlockHitResult) client.crosshairTarget;
        BlockPos pos = hit.getBlockPos();
        BlockState state = client.world.getBlockState(pos);

        if (!(state.getBlock() instanceof VaultBlock) || !state.get(VaultBlock.OMINOUS)) {
            return;
        }

        BlockEntity blockEntity = client.world.getBlockEntity(pos);
        if (!(blockEntity instanceof VaultBlockEntity vault)) {
            return;
        }

        if (!pos.equals(lastVaultPos)) {
            lastVaultPos = pos.toImmutable();
            clickedForCurrentAppearance = false;
        }

        ItemStack displayItem = vault.getSharedData().getDisplayItem();
        boolean isHeavyCore = !displayItem.isEmpty() && displayItem.isOf(Items.HEAVY_CORE);

        if (!isHeavyCore) {
            clickedForCurrentAppearance = false;
            return;
        }

        if (!clickedForCurrentAppearance) {
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
            client.player.swingHand(Hand.MAIN_HAND);
            clickedForCurrentAppearance = true;
            client.player.sendMessage(Text.literal("[HeavyCore AutoClicker] ¡Núcleo Pesado detectado! Clic enviado."), true);
        }
    }

    private static void resetTracking() {
        lastVaultPos = null;
        clickedForCurrentAppearance = false;
    }
}
